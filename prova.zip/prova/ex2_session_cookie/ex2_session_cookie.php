<?php
/*
Refatore o c�digo abaixo, fazendo as altera��es que julgar necess�rio.
1. <?
2.
3. if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
4. header("Location: http://www.google.com");
5. exit();
6. } elseif (isset($_COOKIE['Loggedin']) && $_COOKIE['Loggedin'] == true) {
7. header("Location: http://www.google.com");
8. exit();
9. }
*/
//error_reporting(E_ALL);

if(isset($_POST['flag']))
{
    if(trim(strtoupper($_POST['flag']))=="G")
    {
        session_start();
        session_register("loggedin");
        $loggedin = true;
        $_SESSION['loggedin'] = $loggedin;
    }

    if(trim(strtoupper($_POST['flag']))=="U")
        setcookie("Loggedin", true, time()+3600);

    if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
    {
         header("Location: http://www.google.com");
         exit();
    }
    elseif (isset($_COOKIE['Loggedin']) && $_COOKIE['Loggedin'] == true)
    {
         header("Location: http://www.uol.com.br");
         exit();
    }
}
?>
<html>
<head>
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<title>Ex. 2 session cookie</title>
<script language="javascript">

function valida(flag)
{
    document.form1.flag.value=flag;
    document.form1.submit();
}

</script>
</head>
<body>
<form action="ex2_session_cookie.php" method="post" id="form1" name="form1">
<input type="hidden" name="flag">
<input type="button" value="Google" id="google" name="google" onClick="valida('G');">
<input type="button" value="UOL" id="uol" name="uol" onClick="valida('U');">
</form>
</body>
</html>
