<?php
//error_reporting(E_ALL);
/*
Refatore o c�digo abaixo, fazendo as altera��es que julgar necess�rio.

class MyUserClass
{
 public function getUserList()
 {
   $dbconn = new DatabaseConnection('localhost','user','password');
   $results = $dbconn->query('select name from user');

   sort($results);

   return $results;
 }
}
*/
    //Carrega todas as classes autom�ticamente
    function __autoload($class_name)
    {
        if(file_exists('class/sql/'.$class_name.'.class.php'))
            require_once 'class/sql/'.$class_name.'.class.php';

        if(file_exists('class/core/'.$class_name.'.class.php'))
            require_once 'class/core/'.$class_name.'.class.php';

        if(file_exists('class/dao/'.$class_name.'.class.php'))
            require_once 'class/dao/'.$class_name.'.class.php';

        if(file_exists('class/dto/'.$class_name.'.class.php'))
            require_once 'class/dto/'.$class_name.'.class.php';

        if(file_exists('class/mysql/'.$class_name.'.class.php'))
            require_once 'class/mysql/'.$class_name.'.class.php';

        if(file_exists('class/mysql/ext/'.$class_name.'.class.php'))
            require_once 'class/mysql/ext/'.$class_name.'.class.php';
    }

    //print all rows order by name
    $arr = DAOFactory::getUserDAO()->queryAllOrderBy('name');

    echo "Resultado ordenado por nome:<br>";
    for($i=0;$i<count($arr);$i++){
        $row = $arr[$i];
        echo $row->id.' - '.$row->name.'<br/>';
    }

    //Esta fun��o ordena um array. Os elementos ser�o ordenados do menor para o maior.
    sort($arr);

    echo "<br><br>Resultado ap�s sort():<br>";
    for($i=0;$i<count($arr);$i++){
        $row = $arr[$i];
        echo $row->id.' - '.$row->name.'<br/>';
    }
?>
