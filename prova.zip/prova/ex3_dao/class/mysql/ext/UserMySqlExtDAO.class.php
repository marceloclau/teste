<?php
/**
 * Class that operate on table 'user'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2016-11-23 07:56
 */
class UserMySqlExtDAO extends UserMySqlDAO{

	
}
?>