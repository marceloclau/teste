<?php
	/**
	 * Object represents table 'user'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2016-11-23 07:56	 
	 */
	class User{
		
		var $id;
		var $name;
		
	}
?>