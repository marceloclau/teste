<?php
require_once("TasksRestHandler.php");

$view = "";
if(isset($_GET["view"]))
        $view = $_GET["view"];
/*
controls the RESTful services
URL mapping
*/
switch($view){

        case "all":
                // to handle REST Url prova/ex4_rest/list/
                $provaRestHandler = new TasksRestHandler();
                $provaRestHandler->getAllTaskss();
                break;

        case "single":
                // to handle REST Url prova/ex4_rest/list/<id>/
                $provaRestHandler = new TasksRestHandler();
                $provaRestHandler->getTasks($_GET["id"]);
                break;

        case "insere":
                // to handle REST Url prova/ex4_rest/i/?titulo=$1&descricao=$2&prioridade=$3
                $provaRestHandler = new TasksRestHandler();
                $provaRestHandler->insereTasks($_GET["titulo"],$_GET["descricao"],$_GET["prioridade"]);
                break;

        case "remove":
                // to handle REST Url prova/ex4_rest/e/?id
                $provaRestHandler = new TasksRestHandler();
                $provaRestHandler->removeTasks($_GET["id"]);
                break;

        case "update":
                // to handle REST Url prova/ex4_rest/u/?titulo=$1&descricao=$2&prioridade=$3
                $provaRestHandler = new TasksRestHandler();
                $provaRestHandler->updateTasks($_GET["id"],$_GET["titulo"],$_GET["descricao"],$_GET["prioridade"]);
                break;

        case "" :
                //404 - not found;
                break;
}
?>