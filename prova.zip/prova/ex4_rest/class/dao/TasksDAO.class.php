<?php
/**
 * Intreface DAO
 *
 * @author: http://phpdao.com
 * @date: 2016-11-23 10:52
 */
interface TasksDAO{

        /**
         * Get Domain object by primry key
         *
         * @param String $id primary key
         * @Return Tasks
         */
        public function load($id);

        /**
         * Get all records from table
         */
        public function queryAll();

        /**
         * Get all records from table ordered by field
         * @Param $orderColumn column name
         */
        public function queryAllOrderBy($orderColumn);

        /**
          * Delete record from table
          * @param task primary key
          */
        public function delete($id);

        /**
          * Insert record to table
          *
          * @param Tasks task
          */
        public function insert($task);

        /**
          * Update record in table
          *
          * @param Tasks task
          */
        public function update($task);

        /**
         * Delete all rows
         */
        public function clean();

        public function queryByTitulo($value);

        public function queryByDescricao($value);

        public function queryByIdPrioridade($value);


        public function deleteByTitulo($value);

        public function deleteByDescricao($value);

        public function deleteByIdPrioridade($value);


}
?>