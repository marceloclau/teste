<?php

/**
 * DAOFactory
 * @author: http://phpdao.com
 * @date: ${date}
 */
class DAOFactory{
	
	/**
	 * @return TaskPrioridadeDAO
	 */
	public static function getTaskPrioridadeDAO(){
		return new TaskPrioridadeMySqlExtDAO();
	}

	/**
	 * @return TasksDAO
	 */
	public static function getTasksDAO(){
		return new TasksMySqlExtDAO();
	}

	/**
	 * @return UserDAO
	 */
	public static function getUserDAO(){
		return new UserMySqlExtDAO();
	}


}
?>