<?php
/**
 * Intreface DAO
 *
 * @author: http://phpdao.com
 * @date: 2016-11-23 10:52
 */
interface TaskPrioridadeDAO{

	/**
	 * Get Domain object by primry key
	 *
	 * @param String $id primary key
	 * @Return TaskPrioridade 
	 */
	public function load($id);

	/**
	 * Get all records from table
	 */
	public function queryAll();
	
	/**
	 * Get all records from table ordered by field
	 * @Param $orderColumn column name
	 */
	public function queryAllOrderBy($orderColumn);
	
	/**
 	 * Delete record from table
 	 * @param taskPrioridade primary key
 	 */
	public function delete($id);
	
	/**
 	 * Insert record to table
 	 *
 	 * @param TaskPrioridade taskPrioridade
 	 */
	public function insert($taskPrioridade);
	
	/**
 	 * Update record in table
 	 *
 	 * @param TaskPrioridade taskPrioridade
 	 */
	public function update($taskPrioridade);	

	/**
	 * Delete all rows
	 */
	public function clean();

	public function queryByDescricao($value);


	public function deleteByDescricao($value);


}
?>