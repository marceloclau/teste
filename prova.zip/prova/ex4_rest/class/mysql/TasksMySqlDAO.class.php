<?php
/**
 * Class that operate on table 'tasks'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2016-11-23 10:52
 */
class TasksMySqlDAO implements TasksDAO{

        /**
         * Get Domain object by primry key
         *
         * @param String $id primary key
         * @return TasksMySql
         */
        public function load($id){
                $sql = 'SELECT * FROM tasks WHERE id = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->setNumber($id);
                return $this->getRow($sqlQuery);
        }

        /**
         * Get all records from table
         */
        public function queryAll(){
                $sql = 'SELECT * FROM tasks';
                $sqlQuery = new SqlQuery($sql);
                return $this->getList($sqlQuery);
        }

        /**
         * Get all records from table ordered by field
         *
         * @param $orderColumn column name
         */
        public function queryAllOrderBy($orderColumn){
                $sql = 'SELECT * FROM tasks ORDER BY '.$orderColumn;
                $sqlQuery = new SqlQuery($sql);
                return $this->getList($sqlQuery);
        }

        /**
          * Delete record from table
          * @param task primary key
          */
        public function delete($id){
                $sql = 'DELETE FROM tasks WHERE id = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->setNumber($id);
                return $this->executeUpdate($sqlQuery);
        }

        /**
          * Insert record to table
          *
          * @param TasksMySql task
          */
        public function insert($task){
                $sql = 'INSERT INTO tasks (titulo, descricao, id_prioridade) VALUES (?, ?, ?)';
                $sqlQuery = new SqlQuery($sql);

                $sqlQuery->set($task->titulo);
                $sqlQuery->set($task->descricao);
                $sqlQuery->setNumber($task->idPrioridade);

                $id = $this->executeInsert($sqlQuery);
                $task->id = $id;
                return $id;
        }

        /**
          * Update record in table
          *
          * @param TasksMySql task
          */
        public function update($task){
                $sql = 'UPDATE tasks SET titulo = ?, descricao = ?, id_prioridade = ? WHERE id = ?';
                $sqlQuery = new SqlQuery($sql);

                $sqlQuery->set($task->titulo);
                $sqlQuery->set($task->descricao);
                $sqlQuery->setNumber($task->idPrioridade);

                $sqlQuery->setNumber($task->id);
                return $this->executeUpdate($sqlQuery);
        }

        /**
          * Delete all rows
          */
        public function clean(){
                $sql = 'DELETE FROM tasks';
                $sqlQuery = new SqlQuery($sql);
                return $this->executeUpdate($sqlQuery);
        }

        public function queryByTitulo($value){
                $sql = 'SELECT * FROM tasks WHERE titulo = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->set($value);
                return $this->getList($sqlQuery);
        }

        public function queryByDescricao($value){
                $sql = 'SELECT * FROM tasks WHERE descricao = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->set($value);
                return $this->getList($sqlQuery);
        }

        public function queryByIdPrioridade($value){
                $sql = 'SELECT * FROM tasks WHERE id_prioridade = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->setNumber($value);
                return $this->getList($sqlQuery);
        }


        public function deleteByTitulo($value){
                $sql = 'DELETE FROM tasks WHERE titulo = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->set($value);
                return $this->executeUpdate($sqlQuery);
        }

        public function deleteByDescricao($value){
                $sql = 'DELETE FROM tasks WHERE descricao = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->set($value);
                return $this->executeUpdate($sqlQuery);
        }

        public function deleteByIdPrioridade($value){
                $sql = 'DELETE FROM tasks WHERE id_prioridade = ?';
                $sqlQuery = new SqlQuery($sql);
                $sqlQuery->setNumber($value);
                return $this->executeUpdate($sqlQuery);
        }



        /**
         * Read row
         *
         * @return TasksMySql
         */
        protected function readRow($row){
                $task = new Task();

                $task->id = $row['id'];
                $task->titulo = $row['titulo'];
                $task->descricao = $row['descricao'];
                $task->idPrioridade = $row['id_prioridade'];

                return $task;
        }

        protected function getList($sqlQuery){
                $tab = QueryExecutor::execute($sqlQuery);
                $ret = array();
                for($i=0;$i<count($tab);$i++){
                        $ret[$i] = $this->readRow($tab[$i]);
                }
                return $ret;
        }

        /**
         * Get row
         *
         * @return TasksMySql
         */
        protected function getRow($sqlQuery){
                $tab = QueryExecutor::execute($sqlQuery);
                if(count($tab)==0){
                        return null;
                }
                return $this->readRow($tab[0]);
        }

        /**
         * Execute sql query
         */
        protected function execute($sqlQuery){
                return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Execute sql query
         */
        protected function executeUpdate($sqlQuery){
                return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Query for one row and one column
         */
        protected function querySingleResult($sqlQuery){
                return QueryExecutor::queryForString($sqlQuery);
        }

        /**
         * Insert row to table
         */
        protected function executeInsert($sqlQuery){
                return QueryExecutor::executeInsert($sqlQuery);
        }
}
?>