<?php
/**
 * Class that operate on table 'user'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2016-11-23 10:52
 */
class UserMySqlExtDAO extends UserMySqlDAO{

	
}
?>