<?php
/**
 * Class that operate on table 'tasks'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2016-11-23 10:52
 */
class TasksMySqlExtDAO extends TasksMySqlDAO{

	
}
?>