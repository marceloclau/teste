<?php
/**
 * Class that operate on table 'task_prioridade'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2016-11-23 10:52
 */
class TaskPrioridadeMySqlExtDAO extends TaskPrioridadeMySqlDAO{

	
}
?>