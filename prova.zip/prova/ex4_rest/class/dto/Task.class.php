<?php
        /**
         * Object represents table 'tasks'
         *
              * @author: http://phpdao.com
              * @date: 2016-11-23 10:52
         */
        class Task{

                var $id;

                var $titulo;

                var $descricao;

                var $idPrioridade;


        }
?>