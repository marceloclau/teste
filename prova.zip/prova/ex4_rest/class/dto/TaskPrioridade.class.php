<?php
	/**
	 * Object represents table 'task_prioridade'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2016-11-23 10:52	 
	 */
	class TaskPrioridade{
		
		var $id;
		var $descricao;
		
	}
?>