<?php
	/**
	 * Object represents table 'user'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2016-11-23 10:52	 
	 */
	class User{
		
		var $id;
		var $name;
		
	}
?>