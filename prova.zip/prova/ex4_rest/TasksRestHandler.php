<?php
//error_reporting(E_ALL);

//Carrega todas as classes autom�ticamente
function __autoload($class_name)
{
   if(file_exists('class/sql/'.$class_name.'.class.php'))
      require_once 'class/sql/'.$class_name.'.class.php';

   if(file_exists('class/core/'.$class_name.'.class.php'))
      require_once 'class/core/'.$class_name.'.class.php';

   if(file_exists('class/dao/'.$class_name.'.class.php'))
      require_once 'class/dao/'.$class_name.'.class.php';

   if(file_exists('class/dto/'.$class_name.'.class.php'))
      require_once 'class/dto/'.$class_name.'.class.php';

   if(file_exists('class/mysql/'.$class_name.'.class.php'))
      require_once 'class/mysql/'.$class_name.'.class.php';

   if(file_exists('class/mysql/ext/'.$class_name.'.class.php'))
      require_once 'class/mysql/ext/'.$class_name.'.class.php';
}

require_once("SimpleRest.php");

class TasksRestHandler extends SimpleRest {

        function getAllTaskss() {

                $rawData = DAOFactory::getTasksDAO()->queryAll();

                if(empty($rawData)) {
                        $statusCode = 404;
                        $rawData = array('error' => 'No Taskss found!');
                } else {
                        $statusCode = 200;
                }

                $requestContentType = $_SERVER['HTTP_ACCEPT'];
                $this ->setHttpHeaders($requestContentType, $statusCode);

                if(strpos($requestContentType,'application/json') !== false){
                        $response = $this->encodeJson($rawData);
                        echo $response;
                } else if(strpos($requestContentType,'text/html') !== false){
                        $response = $this->encodeHtml($rawData);
                        echo $response;
                }
        }

        public function encodeHtml($responseData) {

             if(is_array($responseData)) //Arrary de objetos
             {
                $htmlResponse = "<table border='1'>";
                for($i=0;$i<count($responseData);$i++){
                    $row = $responseData[$i];
                    $rowTaskPrioridade = DAOFactory::getTaskPrioridadeDAO()->load($row->idPrioridade);
                    $htmlResponse .= "<tr><td>".$row->id."</td><td>".$row->titulo."</td><td>".$row->descricao."</td><td>".$rowTaskPrioridade->descricao."</td></tr>";
                }
                $htmlResponse .= "</table>";
             }
             elseif(is_int($responseData)) //Inteiro
             {
                $htmlResponse = "<table border='1'>";
                $htmlResponse .= "<tr><td>Rows = ".$responseData."</td></tr>";
                $htmlResponse .= "</table>";
             }
             else //Objeto, um registro filtro id
             {
                $htmlResponse = "<table border='1'>";
                $rowTaskPrioridade = DAOFactory::getTaskPrioridadeDAO()->load($responseData->idPrioridade);
                $htmlResponse .= "<tr><td>".$responseData->id."</td><td>".$responseData->titulo."</td><td>".$responseData->descricao."</td><td>".$rowTaskPrioridade->descricao."</td></tr>";

                $htmlResponse .= "</table>";
             }

             return $htmlResponse;
        }

        public function encodeJson($responseData) {
                $jsonResponse = json_encode($responseData);
                return $jsonResponse;
        }

        public function encodeXml($responseData) {
                // creating object of SimpleXMLElement
                $xml = new SimpleXMLElement('<?xml version="1.0"?><tasks></tasks>');
                foreach($responseData as $key=>$value) {
                        $xml->addChild($key, $value);
                }
                return $xml->asXML();
        }

        public function getTasks($id) {

                $rawData = DAOFactory::getTasksDAO()->load($id);
//                $rowTaskPrioridade = DAOFactory::getTaskPrioridadeDAO()->load($rawData->idPrioridade);

                if(empty($rawData)) {
                        $statusCode = 404;
                        $rawData = array('error' => 'No Tasks found!');
                } else {
                        $statusCode = 200;
                }

                $requestContentType = $_SERVER['HTTP_ACCEPT'];
                $this ->setHttpHeaders($requestContentType, $statusCode);

                if(strpos($requestContentType,'application/json') !== false){
                        $response = $this->encodeJson($rawData);
                        echo $response;
                } else if(strpos($requestContentType,'text/html') !== false){
                        $response = $this->encodeHtml($rawData);
                        echo $response;
                } else if(strpos($requestContentType,'application/xml') !== false){
                        $response = $this->encodeXml($rawData);
                        echo $response;
                }
        }

        public function insereTasks($titulo,$descricao,$prioridade) {

                //start new transaction
                $transaction = new Transaction();
                $task = new Task();
                $task->titulo = $titulo;
                $task->descricao = $descricao;
                $task->idPrioridade = $prioridade;
                DAOFactory::getTasksDAO()->insert($task);
                $rawData = $task;
                //commit transaction
                $transaction->commit();

                if(empty($rawData)) {
                        $statusCode = 404;
                        $rawData = array('error' => 'No Tasks insert!');
                } else {
                        $statusCode = 200;
                }

                $requestContentType = $_SERVER['HTTP_ACCEPT'];
                $this ->setHttpHeaders($requestContentType, $statusCode);

                if(strpos($requestContentType,'application/json') !== false){
                        $response = $this->encodeJson($rawData);
                        echo $response;
                } else if(strpos($requestContentType,'text/html') !== false){
                        $response = $this->encodeHtml($rawData);
                        echo $response;
                } else if(strpos($requestContentType,'application/xml') !== false){
                        $response = $this->encodeXml($rawData);
                        echo $response;
                }
        }

        public function removeTasks($id) {

                //start new transaction
                $transaction = new Transaction();
                $rawData = DAOFactory::getTasksDAO()->delete($id);
                //commit transaction
                $transaction->commit();

                if(empty($rawData)) {
                        $statusCode = 404;
                        $rawData = array('error' => 'No Tasks remove!');
                } else {
                        $statusCode = 200;
                }

                $requestContentType = $_SERVER['HTTP_ACCEPT'];
                $this ->setHttpHeaders($requestContentType, $statusCode);

                if(strpos($requestContentType,'application/json') !== false){
                        $response = $this->encodeJson($rawData);
                        echo $response;
                } else if(strpos($requestContentType,'text/html') !== false){
                        $response = $this->encodeHtml($rawData);
                        echo $response;
                }
        }

        public function updateTasks($id,$titulo,$descricao,$prioridade) {

                //start new transaction
                $transaction = new Transaction();
                $task = DAOFactory::getTasksDAO()->load($id);

                if(trim($titulo)!="")
                    $task->titulo = $titulo;

                if(trim($descricao)!="")
                    $task->descricao = $descricao;

                if(trim($prioridade)!="")
                    $task->idPrioridade = $prioridade;

                $rawData = DAOFactory::getTasksDAO()->update($task);
                //commit transaction
                $transaction->commit();

                if(empty($rawData)) {
                        $statusCode = 404;
                        $rawData = array('error' => 'No Tasks update!');
                } else {
                        $statusCode = 200;
                }

                $requestContentType = $_SERVER['HTTP_ACCEPT'];
                $this ->setHttpHeaders($requestContentType, $statusCode);

                if(strpos($requestContentType,'application/json') !== false){
                        $response = $this->encodeJson($rawData);
                        echo $response;
                } else if(strpos($requestContentType,'text/html') !== false){
                        $response = $this->encodeHtml($rawData);
                        echo $response;
                }
        }

}
?>