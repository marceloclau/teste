<?php
//error_reporting(E_ALL);
/*
Escreva um programa que imprima n�meros de 1 a 100.
Mas, para m�ltiplos de 3 imprima �Fizz� em vez do n�mero e para m�ltiplos de 5 imprima �Buzz�.
Para n�meros m�ltiplos de ambos (3 e 5), imprima �FizzBuzz�.
*/

for($i=1;$i<=100;$i++)
{
    if($i%3==0 && $i%5==0)
        echo "FizzBuzz<br>";
    elseif($i%3==0)
        echo "Fizz<br>";
    elseif($i%5==0)
        echo "Buzz<br>";
    else
        echo $i."<br>";
}
?>
